A Pen created at CodePen.io. You can find this one at https://codepen.io/Zaku/pen/xdNQNo.

 Clean version of https://codepen.io/Zaku/pen/JNzYXP

See shot on dribbble: https://dribbble.com/shots/3529235--version-2