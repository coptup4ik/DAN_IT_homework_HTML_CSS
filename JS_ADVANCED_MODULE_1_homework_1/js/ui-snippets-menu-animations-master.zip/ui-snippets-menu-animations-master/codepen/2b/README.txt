A Pen created at CodePen.io. You can find this one at https://codepen.io/Zaku/pen/JNzYXP.

 All three versions so far:
1: https://codepen.io/Zaku/pen/vcaFr
2: https://codepen.io/Zaku/pen/JNzYXP
3: https://codepen.io/Zaku/pen/LyvZjY

There is also a clean version which is easier to reuse: https://codepen.io/Zaku/pen/xdNQNo

See shot on dribbble: https://dribbble.com/shots/3529235--version-2
