A Pen created at CodePen.io. You can find this one at https://codepen.io/Zaku/pen/fmjJi.

 Live Version of this Dribbble shot: http://drbl.in/lUcg