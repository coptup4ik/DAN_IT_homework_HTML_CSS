A Pen created at CodePen.io. You can find this one at https://codepen.io/Zaku/pen/vcaFr.

 Live Version of this Dribbble shot: http://drbl.in/lUcg

All three versions so far:
1: https://codepen.io/Zaku/pen/vcaFr
2: https://codepen.io/Zaku/pen/JNzYXP
3: https://codepen.io/Zaku/pen/LyvZjY
