# Menu Button Animations

Four different menu animations for menu button toggle between hamburger, cross and back icon.

You can see a full page Preview on [GitHub Pages](https://tamino-martinius.github.io/ui-snippets-menu-animations) or do quick changes on [CodePen](https://codepen.io/Zaku/pen/ejLNJL/).

![Menu Preview](public/preview-menu.gif?raw=true)
![Dots Preview](public/preview-dots.gif?raw=true)
